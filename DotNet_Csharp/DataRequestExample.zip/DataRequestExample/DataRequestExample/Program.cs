﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Xml.Serialization;

namespace DataRequestExample
{
	class Program
	{
		static string webservice = "https://ws.lim.com";
		static string rels = "NG, HO, HU, CL, PN, NYM.COAL";
		static string cols = "Open, High, Low, Close, Volume";
		static string startDate = "1980-01-03";
		static string endDate = "2015-05-01";
		static DateTime sDate = DateTime.Parse(startDate).AddDays(-1);
		static DateTime eDate = DateTime.Parse(endDate).AddDays(1);
		static string creds = null;
		
		public static void Main(string[] args)
		{
			bool exit = false;
			while (!exit) {
				Console.WriteLine("\n/*******************************************************/");
				Console.WriteLine("/*  Morningstar Commodity Data Webservice C# Examples  */");
				Console.WriteLine("/*                                                     */");
				Console.WriteLine("/*          1: Get Schema Example                      */");
				Console.WriteLine("/*          2: Get Records Example                     */");
				Console.WriteLine("/*          3: Query Execute Example                   */");
				Console.WriteLine("/*          Q: Quit                                    */");
				Console.WriteLine("/*                                                     */");
				Console.WriteLine("/*******************************************************/");
				Console.WriteLine("\nEnter selection: ");
				
				ConsoleKeyInfo keyInfo = Console.ReadKey(true);
				char ch = keyInfo.KeyChar;
				switch(ch)
				{
					case '1':
						Console.WriteLine("\n=== Running Get Schema Example ===");
						DoGetSchemaExample();
						break;
					case '2':
						Console.WriteLine("\n=== Running Get Records Example ===");
						Console.WriteLine("Rels: {0}", rels);
						Console.WriteLine("Cols: {0}", cols);
						DoDataRequest(GetDataRequestForGetRecords());
						break;
					case '3':
						Console.WriteLine("\n=== Running Exectute Query Example ===");
						DoDataRequest(GetDataRequestForQuery());
						break;
					case 'Q':
					case 'q':
						exit = true;
						break;
				}
			}

		}
		
		private static void DoDataRequest(String dataRequestXml)
		{
			
			byte[] bytes = System.Text.Encoding.UTF8.GetBytes(dataRequestXml);

			WebRequest req = BuildRequest("/rs/api/datarequests", "POST", bytes);
			DataRequestResponse drr = ExecuteHttpDataRequest(req, typeof(DataRequestResponse));
			
			while (drr.status == Status.INCOMPLETE)
			{
				req = BuildRequest("/rs/api/datarequests/" + drr.id, "GET", null);
				drr = ExecuteHttpDataRequest(req, typeof(DataRequestResponse));
			}
			ProcessDataRequestResponse(drr);
		}
		
		
		private static void ProcessDataRequestResponse(DataRequestResponse drr)
		{
			Console.WriteLine("DataRequest Status: {0} {1}", drr.status, drr.statusMsg);
			List<Report> reports = drr.reports;
			foreach (Report report in reports)
			{
				Console.WriteLine();
				List<ReportBlock> blocks = report.reportBlocks;
				foreach (ReportBlock block in blocks)
				{
					
					List<System.DateTime> dates = block.rowDates;

					// d1r1c1, d1r1c2, d1r2c1, d1r2c2, d2r1c1, d2r1c2, d2r2c1, d2r2c2
					List<Double> values = block.values;
					
					int numRels = block.numRows/dates.Count;
					int numDates = dates.Count;
					int numCols = block.numCols;
					int numRows = block.numRows;

					Console.WriteLine("Rows: {0}", numRows);
					Console.WriteLine("Rels: {0}", numRels);
					Console.WriteLine("Cols: {0}", numCols);
					Console.WriteLine("Dates: {0}",  dates.Count);
					Console.WriteLine("Vals: {0}",  values.Count);
					
					for(int ii=0; ii<values.Count; ii++)
					{
						if (ii % (numRels*numCols) == 0) {
							Console.Write("\n{0}\t", dates[ii/(numRels*numCols)].ToString("yyyy.MM.dd"));
						}

						Console.Write("{0}\t", values[ii]);
					}
				}
			}
			

		}

		/*
		 * Make the web service call and return the response as a DataRequestResponse object.
		 */
		private static DataRequestResponse ExecuteHttpDataRequest(WebRequest req, Type type)
		{
			DataRequestResponse drr = null;
			
			try {
				Console.WriteLine("{0} {1}", req.Method, req.RequestUri.ToString());
				
				// HTTP request is made.
				WebResponse response = req.GetResponse();
				
				StreamReader streamReader = new StreamReader(response.GetResponseStream());
				
				XmlSerializer serializer = new XmlSerializer(type);
				
				// All data is read off the stream and deserialized into a DataRequestResponse object.
				drr = (DataRequestResponse) serializer.Deserialize(streamReader);
				
			} catch (WebException e) {
				using (WebResponse response = e.Response)
				{
					HttpWebResponse httpResponse = (HttpWebResponse)response;
					Console.WriteLine("Error code: {0}", httpResponse.StatusCode);
					using (var streamReader = new StreamReader(response.GetResponseStream()))
						Console.WriteLine(streamReader.ReadToEnd());
				}
			}
			
			return drr;

		}

		
		/*
		 * Get Schema Example.
		 * Performs HTTP request to get schema information for a specified relation.
		 */
		private static void DoGetSchemaExample()
		{
			Console.Write("Enter a relation: ");
			String relation = Console.ReadLine();
			
			StringBuilder sb = new StringBuilder();
			sb.Append(webservice + "/rs/api/schema/relations/" + relation + "?showChildren=true&desc=true&cDesc=true&showColumns=true&dateRange=false&dataPreview=false");
			
			WebRequest req = WebRequest.Create(sb.ToString());
			SetBasicAuthHeader(req);
			req.Method = "GET";
			req.ContentType = "text/xml";
			
			Console.WriteLine("{0} {1}", req.Method, req.RequestUri);
			try {
				using (WebResponse response = req.GetResponse())
				{
					HttpWebResponse httpResponse = (HttpWebResponse)response;
					Console.WriteLine("Http content type: {0}", httpResponse.ContentType);
					Console.WriteLine("Http status code: {0}", httpResponse.StatusCode);
					
					
					var streamReader = new StreamReader(response.GetResponseStream());
					
					Console.WriteLine(FormatXmlString(streamReader.ReadToEnd()));

				}
			} catch (WebException e) {
				using (WebResponse response = e.Response)
				{
					HttpWebResponse httpResponse = (HttpWebResponse)response;
					Console.WriteLine("Error code: {0}", httpResponse.StatusCode);
					using (var streamReader = new StreamReader(response.GetResponseStream()))
						Console.WriteLine(streamReader.ReadToEnd());
				}
			}
			
		}
		
		
		/******************************
		 * 
		 * HELPER METHODS
		 * 
		 ******************************/
		private static void SetBasicAuthHeader(WebRequest req)
		{
			// Most API requests require Basic Authentication. Here we get the username:password from a file.
			String creds = GetCreds();

			creds = Convert.ToBase64String(Encoding.Default.GetBytes(creds));
			req.Headers["Authorization"] = "Basic " + creds;
		}
		
		private static string FormatXmlString(string xmlString)
		{
			System.Xml.Linq.XElement element = System.Xml.Linq.XElement.Parse(xmlString);
			return element.ToString();
		}
		
		private static string GetDataRequestForQuery()
		{
			StringBuilder buff = new StringBuilder("<DataRequest><Query><Text>SHOW\n");
			
			int i = 1;
			foreach(String rel in rels.Split(','))
			{
				foreach(String col in cols.Split(','))
				{
					buff.Append(String.Format(" {0}: {1} of {2}\n", i++, col, rel));
				}
			}
			
			buff.Append(String.Format("WHEN Date is after {0} AND Date is before {1}</Text></Query></DataRequest>", sDate.ToString("MM/dd/yyyy"), eDate.ToString("dd/MM/yyyy")));
			
			return buff.ToString();
		}
		
		private static string GetDataRequestForGetRecords()
		{
			StringBuilder postData = new StringBuilder();
			postData.Append("<DataRequest> ");
			postData.Append("<GetRecsParams> ");
			postData.Append(String.Format("<Rels>{0}</Rels><Cols>{1}</Cols>", rels, cols));
			postData.Append("<nu>1</nu> ");
			postData.Append("<Unit>DAYS</Unit> ");
			postData.Append(String.Format("<fd>{0}</fd><td>{1}</td>", startDate, endDate));
			postData.Append("<mdf>FILL_NAN</mdf>");
			postData.Append("<mhf>FILL_NAN</mhf>");
			postData.Append("<sn>SKIP_NONE</sn>");
			postData.Append("<LimitMode>BY_RECORDS</LimitMode>");
			postData.Append("<LimitSize>100000</LimitSize>");
			postData.Append("</GetRecsParams>");
			postData.Append("</DataRequest>");
			
			return postData.ToString();
			
		}
		
		private static WebRequest BuildRequest(String uriPath, String method, byte [] bytes)
		{
			WebRequest req = WebRequest.Create(webservice + uriPath);
			SetBasicAuthHeader(req);
			req.Method = method;
			req.ContentType = "text/xml";

			// Since we have the credentials let's pre-authenticate.
			req.PreAuthenticate = true;
			
			if (bytes != null) {
				// HTTP Connection is established.
				Stream stream = req.GetRequestStream();
				
				stream.Write(bytes, 0, bytes.Length);
				stream.Close();

			}
			
			
			return req;
		}
		
		private static string GetCreds() {
			if (creds == null) 
			{
			Console.Write("Please enter your username: ");
			string u = Console.ReadLine();
			Console.Write("Please enter password for [{0}]: ", u);
			string p = ReadPassword();
			creds = String.Format("{0}:{1}", u, p);
			}
			
			return creds;
		}
		
		public static string ReadPassword() {
			Stack<string> pass = new Stack<string>();
			
			for (ConsoleKeyInfo consKeyInfo = Console.ReadKey(true);
			     consKeyInfo.Key != ConsoleKey.Enter; consKeyInfo = Console.ReadKey(true))
			{
				if (consKeyInfo.Key == ConsoleKey.Backspace)
				{
					try
					{
						Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
						Console.Write(" ");
						Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
						pass.Pop();
					}
					catch (InvalidOperationException ex)
					{
						/* Nothing to delete, go back to previous position */
						Console.SetCursorPosition(Console.CursorLeft + 1, Console.CursorTop);
					}
				}
				else {
					Console.Write("*");
					pass.Push(consKeyInfo.KeyChar.ToString());
				}
			}
			String[] password = pass.ToArray();
			Array.Reverse(password);
			Console.WriteLine();
			return string.Join(string.Empty, password);
		}

		
	}
	
}